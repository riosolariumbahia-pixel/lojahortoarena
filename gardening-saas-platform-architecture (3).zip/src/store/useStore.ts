import { create } from 'zustand';

export type UserRole = 'admin' | 'lojista' | 'cliente';
export type ViewMode = 'landing' | 'admin' | 'lojista' | 'cliente';
export type ThemeMode = 'light' | 'dark';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  tenantId?: string;
  xp: number;
  level: number;
  coins: number;
  streak: number;
}

export interface Plant {
  id: string;
  name: string;
  species: string;
  image: string;
  health: number;
  waterDays: number;
  lastWatered: string;
  growth: number;
  notes: string[];
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  image: string;
  description: string;
  rating: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  joinDate: string;
  totalSpent: number;
  plantsOwned: number;
  engagement: 'alta' | 'media' | 'baixa';
  birthday: string;
  lastVisit: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'water' | 'growth' | 'reward' | 'promo' | 'achievement';
  read: boolean;
  timestamp: string;
  icon: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
  xpReward: number;
  coinReward: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'weekly';
  progress: number;
  maxProgress: number;
  xpReward: number;
  coinReward: number;
  completed: boolean;
  icon: string;
}

// Dados locais do lojista (persistem na sessão)
export interface LojistaData {
  customers: Customer[];
  products: Product[];
  whatsappTemplates: WhatsAppTemplate[];
  whatsappAutomations: WhatsAppAutomation[];
  orders: OrderItem[];
}

export interface WhatsAppTemplate {
  id: string;
  name: string;
  message: string;
  category: string;
  sends: number;
  opens: number;
  isActive: boolean;
}

export interface WhatsAppAutomation {
  id: string;
  name: string;
  templateId: string;
  trigger: string;
  triggerTime: string;
  isActive: boolean;
  sentCount: number;
}

export interface OrderItem {
  id: string;
  customerName: string;
  total: number;
  status: string;
  date: string;
  items: number;
}

interface AppState {
  currentView: ViewMode;
  setCurrentView: (view: ViewMode) => void;
  theme: ThemeMode;
  toggleTheme: () => void;
  user: User | null;
  setUser: (user: User | null) => void;
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  notifications: Notification[];
  addNotification: (n: Notification) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  activeLojistaTab: string;
  setActiveLojistaTab: (tab: string) => void;
  activeClienteTab: string;
  setActiveClienteTab: (tab: string) => void;
  chatOpen: boolean;
  setChatOpen: (open: boolean) => void;
  showOnboarding: boolean;
  setShowOnboarding: (show: boolean) => void;
  // Dados do lojista
  lojistaData: LojistaData;
  addCustomer: (c: Customer) => void;
  removeCustomer: (id: string) => void;
  addProduct: (p: Product) => void;
  removeProduct: (id: string) => void;
  addWhatsAppTemplate: (t: WhatsAppTemplate) => void;
  removeWhatsAppTemplate: (id: string) => void;
  toggleAutomation: (id: string) => void;
  addAutomation: (a: WhatsAppAutomation) => void;
  addOrder: (o: OrderItem) => void;
}

export const useStore = create<AppState>((set) => ({
  currentView: 'landing',
  setCurrentView: (view) => set({ currentView: view }),
  theme: 'light',
  toggleTheme: () => set((state) => ({ theme: state.theme === 'light' ? 'dark' : 'light' })),
  user: null,
  setUser: (user) => set({ user }),
  sidebarOpen: false,
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  notifications: [],
  addNotification: (n) => set((state) => ({ notifications: [n, ...state.notifications] })),
  markNotificationRead: (id) => set((state) => ({
    notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n)
  })),
  clearNotifications: () => set({ notifications: [] }),
  activeLojistaTab: 'dashboard',
  setActiveLojistaTab: (tab) => set({ activeLojistaTab: tab }),
  activeClienteTab: 'home',
  setActiveClienteTab: (tab) => set({ activeClienteTab: tab }),
  chatOpen: false,
  setChatOpen: (open) => set({ chatOpen: open }),
  showOnboarding: false,
  setShowOnboarding: (show) => set({ showOnboarding: show }),
  // Dados do lojista — COMEÇA ZERADO
  lojistaData: {
    customers: [],
    products: [],
    whatsappTemplates: [],
    whatsappAutomations: [],
    orders: [],
  },
  addCustomer: (c) => set((state) => ({
    lojistaData: { ...state.lojistaData, customers: [...state.lojistaData.customers, c] }
  })),
  removeCustomer: (id) => set((state) => ({
    lojistaData: { ...state.lojistaData, customers: state.lojistaData.customers.filter(c => c.id !== id) }
  })),
  addProduct: (p) => set((state) => ({
    lojistaData: { ...state.lojistaData, products: [...state.lojistaData.products, p] }
  })),
  removeProduct: (id) => set((state) => ({
    lojistaData: { ...state.lojistaData, products: state.lojistaData.products.filter(p => p.id !== id) }
  })),
  addWhatsAppTemplate: (t) => set((state) => ({
    lojistaData: { ...state.lojistaData, whatsappTemplates: [...state.lojistaData.whatsappTemplates, t] }
  })),
  removeWhatsAppTemplate: (id) => set((state) => ({
    lojistaData: { ...state.lojistaData, whatsappTemplates: state.lojistaData.whatsappTemplates.filter(t => t.id !== id) }
  })),
  toggleAutomation: (id) => set((state) => ({
    lojistaData: {
      ...state.lojistaData,
      whatsappAutomations: state.lojistaData.whatsappAutomations.map(a =>
        a.id === id ? { ...a, isActive: !a.isActive } : a
      ),
    }
  })),
  addAutomation: (a) => set((state) => ({
    lojistaData: { ...state.lojistaData, whatsappAutomations: [...state.lojistaData.whatsappAutomations, a] }
  })),
  addOrder: (o) => set((state) => ({
    lojistaData: { ...state.lojistaData, orders: [o, ...state.lojistaData.orders] }
  })),
}));
