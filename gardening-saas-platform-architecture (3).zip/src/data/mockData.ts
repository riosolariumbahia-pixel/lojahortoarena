import type { Product, Customer, Achievement, Mission, Plant } from '../store/useStore';

export const PLANS = [
  {
    id: 'starter',
    name: 'Semente',
    price: 97,
    priceAnnual: 77,
    features: ['Até 100 clientes', 'CRM básico', 'Catálogo 50 produtos', 'Suporte email', '1 usuário admin'],
    highlighted: false,
    icon: '🌱',
  },
  {
    id: 'growth',
    name: 'Crescimento',
    price: 197,
    priceAnnual: 157,
    features: ['Até 500 clientes', 'CRM completo', 'Catálogo ilimitado', 'WhatsApp integrado', 'IA básica', '3 usuários admin', 'Relatórios avançados'],
    highlighted: true,
    icon: '🌿',
  },
  {
    id: 'pro',
    name: 'Floração',
    price: 397,
    priceAnnual: 317,
    features: ['Clientes ilimitados', 'CRM + Automação', 'IA Premium', 'WhatsApp + Campanhas', 'Marketplace', 'White-label', '10 usuários admin', 'API acesso', 'Suporte prioritário'],
    highlighted: false,
    icon: '🌸',
  },
  {
    id: 'enterprise',
    name: 'Jardim Completo',
    price: 797,
    priceAnnual: 637,
    features: ['Tudo do Floração', 'Multi-lojas', 'IA dedicada', 'Integrações custom', 'Gerente de sucesso', 'SLA 99.9%', 'Treinamento equipe', 'Dashboard BI'],
    highlighted: false,
    icon: '🏡',
  },
];

export const mockProducts: Product[] = [
  { id: '1', name: 'Rosa Trepadeira', category: 'Mudas', price: 35.90, stock: 48, image: 'https://images.pexels.com/photos/37331386/pexels-photo-37331386.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Rosa trepadeira vermelha, perfeita para muros e pergolados.', rating: 4.8 },
  { id: '2', name: 'Suculenta Mix (Kit 6)', category: 'Mudas', price: 49.90, stock: 124, image: 'https://images.pexels.com/photos/4299171/pexels-photo-4299171.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Kit com 6 suculentas variadas em vasinhos decorativos.', rating: 4.9 },
  { id: '3', name: 'Adubo Orgânico Premium', category: 'Fertilizantes', price: 28.90, stock: 89, image: 'https://images.pexels.com/photos/6508556/pexels-photo-6508556.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Adubo 100% orgânico para todas as plantas.', rating: 4.7 },
  { id: '4', name: 'Vaso Cerâmica Artesanal', category: 'Vasos', price: 79.90, stock: 33, image: 'https://images.pexels.com/photos/32513154/pexels-photo-32513154.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Vaso de cerâmica pintado à mão, estilo minimalista.', rating: 4.6 },
  { id: '5', name: 'Kit Ferramentas Jardim', category: 'Ferramentas', price: 119.90, stock: 22, image: 'https://images.pexels.com/photos/6508425/pexels-photo-6508425.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Kit completo com pá, rastelo, tesoura de poda e luvas.', rating: 4.5 },
  { id: '6', name: 'Orquídea Phalaenopsis', category: 'Mudas', price: 65.90, stock: 56, image: 'https://images.pexels.com/photos/13384736/pexels-photo-13384736.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Orquídea premium com flores brancas e rosa.', rating: 4.9 },
  { id: '7', name: 'Semente Tomate Cereja', category: 'Sementes', price: 12.90, stock: 200, image: 'https://images.pexels.com/photos/6508827/pexels-photo-6508827.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Sementes orgânicas de tomate cereja. Rende 50 mudas.', rating: 4.4 },
  { id: '8', name: 'Substrato Premium 5L', category: 'Substratos', price: 22.90, stock: 145, image: 'https://images.pexels.com/photos/20324601/pexels-photo-20324601.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=300', description: 'Substrato premium com perlita e vermiculita.', rating: 4.7 },
];

export const mockCustomers: Customer[] = [
  { id: '1', name: 'Maria Silva', email: 'maria@email.com', phone: '(11) 99999-1111', joinDate: '2024-01-15', totalSpent: 1250.00, plantsOwned: 12, engagement: 'alta', birthday: '1985-03-20', lastVisit: '2024-12-10' },
  { id: '2', name: 'João Santos', email: 'joao@email.com', phone: '(11) 99999-2222', joinDate: '2024-02-20', totalSpent: 890.50, plantsOwned: 8, engagement: 'alta', birthday: '1990-07-14', lastVisit: '2024-12-09' },
  { id: '3', name: 'Ana Costa', email: 'ana@email.com', phone: '(11) 99999-3333', joinDate: '2024-03-10', totalSpent: 456.00, plantsOwned: 5, engagement: 'media', birthday: '1988-11-05', lastVisit: '2024-12-05' },
  { id: '4', name: 'Carlos Lima', email: 'carlos@email.com', phone: '(11) 99999-4444', joinDate: '2024-04-05', totalSpent: 2100.00, plantsOwned: 20, engagement: 'alta', birthday: '1982-09-30', lastVisit: '2024-12-11' },
  { id: '5', name: 'Lucia Pereira', email: 'lucia@email.com', phone: '(11) 99999-5555', joinDate: '2024-05-12', totalSpent: 320.00, plantsOwned: 3, engagement: 'baixa', birthday: '1995-01-22', lastVisit: '2024-11-20' },
  { id: '6', name: 'Pedro Oliveira', email: 'pedro@email.com', phone: '(11) 99999-6666', joinDate: '2024-06-18', totalSpent: 780.00, plantsOwned: 7, engagement: 'media', birthday: '1992-06-08', lastVisit: '2024-12-08' },
  { id: '7', name: 'Fernanda Souza', email: 'fernanda@email.com', phone: '(11) 99999-7777', joinDate: '2024-07-22', totalSpent: 1560.00, plantsOwned: 15, engagement: 'alta', birthday: '1987-04-15', lastVisit: '2024-12-11' },
  { id: '8', name: 'Roberto Almeida', email: 'roberto@email.com', phone: '(11) 99999-8888', joinDate: '2024-08-01', totalSpent: 190.00, plantsOwned: 2, engagement: 'baixa', birthday: '1998-12-03', lastVisit: '2024-11-15' },
];

export const mockPlants: Plant[] = [
  { id: '1', name: 'Rosa Vermelha', species: 'Rosa gallica', image: 'https://images.pexels.com/photos/37331386/pexels-photo-37331386.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400', health: 85, waterDays: 2, lastWatered: '2024-12-09', growth: 72, notes: ['Podada em novembro', 'Nova floração esperada em janeiro'] },
  { id: '2', name: 'Tomateiro Cereja', species: 'Solanum lycopersicum', image: 'https://images.pexels.com/photos/6508827/pexels-photo-6508827.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400', health: 92, waterDays: 1, lastWatered: '2024-12-10', growth: 45, notes: ['Primeiros frutos aparecendo', 'Adubar semanalmente'] },
  { id: '3', name: 'Suculenta Echeveria', species: 'Echeveria elegans', image: 'https://images.pexels.com/photos/4299171/pexels-photo-4299171.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400', health: 98, waterDays: 7, lastWatered: '2024-12-05', growth: 90, notes: ['Planta resistente', 'Propagar na primavera'] },
  { id: '4', name: 'Orquídea Phalaenopsis', species: 'Phalaenopsis amabilis', image: 'https://images.pexels.com/photos/13384736/pexels-photo-13384736.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400', health: 78, waterDays: 3, lastWatered: '2024-12-08', growth: 60, notes: ['Precisa de mais umidade', 'Trocar substrato em fevereiro'] },
];

export const mockAchievements: Achievement[] = [
  { id: '1', title: 'Primeiro Broto', description: 'Cadastre sua primeira planta', icon: '🌱', unlocked: true, progress: 1, maxProgress: 1, xpReward: 50, coinReward: 20 },
  { id: '2', title: 'Mão Verde', description: 'Mantenha 5 plantas saudáveis por 30 dias', icon: '🖐️', unlocked: true, progress: 5, maxProgress: 5, xpReward: 200, coinReward: 100 },
  { id: '3', title: 'Jardineiro Dedicado', description: 'Faça login 7 dias seguidos', icon: '🔥', unlocked: true, progress: 7, maxProgress: 7, xpReward: 150, coinReward: 75 },
  { id: '4', title: 'Colecionador Verde', description: 'Tenha 10 espécies diferentes', icon: '🏆', unlocked: false, progress: 4, maxProgress: 10, xpReward: 500, coinReward: 250 },
  { id: '5', title: 'Mestre da Irrigação', description: 'Regue suas plantas no horário certo 30 vezes', icon: '💧', unlocked: false, progress: 18, maxProgress: 30, xpReward: 300, coinReward: 150 },
  { id: '6', title: 'Fotógrafo Botânico', description: 'Registre 20 fotos no Diário do Jardim', icon: '📸', unlocked: false, progress: 8, maxProgress: 20, xpReward: 250, coinReward: 120 },
  { id: '7', title: 'Guru das Plantas', description: 'Alcance nível 10', icon: '🧙', unlocked: false, progress: 5, maxProgress: 10, xpReward: 1000, coinReward: 500 },
  { id: '8', title: 'Comprador VIP', description: 'Faça 10 compras na loja', icon: '🛒', unlocked: false, progress: 3, maxProgress: 10, xpReward: 400, coinReward: 200 },
];

export const mockMissions: Mission[] = [
  { id: '1', title: 'Regue todas as plantas', description: 'Marque todas as plantas como regadas hoje', type: 'daily', progress: 2, maxProgress: 4, xpReward: 30, coinReward: 15, completed: false, icon: '💧' },
  { id: '2', title: 'Tire uma foto', description: 'Registre uma foto de uma planta', type: 'daily', progress: 0, maxProgress: 1, xpReward: 20, coinReward: 10, completed: false, icon: '📷' },
  { id: '3', title: 'Consulte a IA', description: 'Faça uma pergunta ao Jardineiro Virtual', type: 'daily', progress: 1, maxProgress: 1, xpReward: 15, coinReward: 5, completed: true, icon: '🤖' },
  { id: '4', title: 'Desafio da Semana: Adubar', description: 'Adube 3 plantas durante esta semana', type: 'weekly', progress: 1, maxProgress: 3, xpReward: 100, coinReward: 50, completed: false, icon: '🧪' },
  { id: '5', title: 'Social: Compartilhe', description: 'Compartilhe uma foto do seu jardim', type: 'weekly', progress: 0, maxProgress: 1, xpReward: 80, coinReward: 40, completed: false, icon: '📱' },
  { id: '6', title: 'Visite a Loja', description: 'Explore o marketplace e favorite 3 produtos', type: 'weekly', progress: 2, maxProgress: 3, xpReward: 60, coinReward: 30, completed: false, icon: '🛍️' },
];

export const salesData = [
  { month: 'Jan', vendas: 4200, meta: 5000 },
  { month: 'Fev', vendas: 5100, meta: 5000 },
  { month: 'Mar', vendas: 6800, meta: 6000 },
  { month: 'Abr', vendas: 5600, meta: 6000 },
  { month: 'Mai', vendas: 7200, meta: 7000 },
  { month: 'Jun', vendas: 8100, meta: 7000 },
  { month: 'Jul', vendas: 7500, meta: 8000 },
  { month: 'Ago', vendas: 9200, meta: 8000 },
  { month: 'Set', vendas: 8800, meta: 9000 },
  { month: 'Out', vendas: 10500, meta: 9000 },
  { month: 'Nov', vendas: 11200, meta: 10000 },
  { month: 'Dez', vendas: 13800, meta: 12000 },
];

export const categoryData = [
  { name: 'Mudas', value: 42, color: '#22c55e' },
  { name: 'Vasos', value: 18, color: '#b07d42' },
  { name: 'Fertilizantes', value: 15, color: '#0ea5e9' },
  { name: 'Sementes', value: 12, color: '#ec4899' },
  { name: 'Ferramentas', value: 8, color: '#f59e0b' },
  { name: 'Decoração', value: 5, color: '#8b5cf6' },
];

export const engagementData = [
  { day: 'Seg', usuarios: 120 },
  { day: 'Ter', usuarios: 145 },
  { day: 'Qua', usuarios: 132 },
  { day: 'Qui', usuarios: 168 },
  { day: 'Sex', usuarios: 189 },
  { day: 'Sáb', usuarios: 210 },
  { day: 'Dom', usuarios: 195 },
];

export const chatMessages = [
  { id: '1', role: 'assistant' as const, content: 'Olá! 🌿 Sou o Jardineiro Virtual com IA. Como posso ajudar seu jardim hoje?' },
];

export const LEVELS = [
  { level: 1, title: 'Semente', xpRequired: 0, icon: '🌱' },
  { level: 2, title: 'Broto', xpRequired: 100, icon: '🌿' },
  { level: 3, title: 'Muda', xpRequired: 300, icon: '🪴' },
  { level: 4, title: 'Planta', xpRequired: 600, icon: '🌳' },
  { level: 5, title: 'Jardineiro', xpRequired: 1000, icon: '👨‍🌾' },
  { level: 6, title: 'Botânico', xpRequired: 1500, icon: '🔬' },
  { level: 7, title: 'Mestre Verde', xpRequired: 2200, icon: '🏆' },
  { level: 8, title: 'Guru das Plantas', xpRequired: 3000, icon: '🧙' },
  { level: 9, title: 'Lenda do Jardim', xpRequired: 4000, icon: '👑' },
  { level: 10, title: 'Deus da Natureza', xpRequired: 5500, icon: '🌍' },
];
