import { useState, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { LEVELS, mockAchievements, mockMissions } from '../data/mockData';
import { useStore } from '../store/useStore';
import toast from 'react-hot-toast';

export function useGamification() {
  const { user, setUser, addNotification } = useStore();
  const [loading] = useState(false);

  const getCurrentLevel = useCallback(() => {
    if (!user) return LEVELS[0];
    return LEVELS.find(l => l.level === user.level) || LEVELS[0];
  }, [user]);

  const getNextLevel = useCallback(() => {
    if (!user) return LEVELS[1];
    return LEVELS.find(l => l.level === user.level + 1);
  }, [user]);

  const getXpProgress = useCallback(() => {
    if (!user) return 0;
    const current = getCurrentLevel();
    const next = getNextLevel();
    if (!next) return 100;
    return ((user.xp - current.xpRequired) / (next.xpRequired - current.xpRequired)) * 100;
  }, [user, getCurrentLevel, getNextLevel]);

  const addXp = useCallback(async (amount: number, reason?: string) => {
    if (!user) return;

    const newXp = user.xp + amount;
    let newLevel = user.level;
    let leveledUp = false;

    // Check for level up
    for (let i = LEVELS.length - 1; i >= 0; i--) {
      if (newXp >= LEVELS[i].xpRequired && LEVELS[i].level > user.level) {
        newLevel = LEVELS[i].level;
        leveledUp = true;
        break;
      }
    }

    // Update local state
    setUser({ ...user, xp: newXp, level: newLevel });

    // Show toast
    toast.success(`+${amount} XP${reason ? ` - ${reason}` : ''}`, {
      icon: '⭐',
      duration: 2000,
    });

    if (leveledUp) {
      const newLevelInfo = LEVELS.find(l => l.level === newLevel);
      toast.success(`🎉 Parabéns! Você subiu para o nível ${newLevel} - ${newLevelInfo?.title}!`, {
        duration: 4000,
      });

      addNotification({
        id: Date.now().toString(),
        title: 'Nível Alcançado! 🎉',
        message: `Você atingiu o nível ${newLevel} - ${newLevelInfo?.title}!`,
        type: 'achievement',
        read: false,
        timestamp: new Date().toISOString(),
        icon: newLevelInfo?.icon || '🏆',
      });
    }

    // Update in Supabase if configured
    if (isSupabaseConfigured && user.id) {
      try {
        await supabase.rpc('add_xp', { user_id: user.id, amount } as any);
      } catch (err) {
        console.error('Error updating XP in database:', err);
      }
    }
  }, [user, setUser, addNotification]);

  const addCoins = useCallback(async (amount: number, reason?: string) => {
    if (!user) return;

    setUser({ ...user, coins: user.coins + amount });

    toast.success(`+${amount} moedas verdes${reason ? ` - ${reason}` : ''}`, {
      icon: '🪙',
      duration: 2000,
    });

    // Update in Supabase if configured
    if (isSupabaseConfigured && user.id) {
      try {
        await supabase
          .from('profiles')
          .update({ coins: user.coins + amount } as never)
          .eq('id', user.id);
      } catch (err) {
        console.error('Error updating coins in database:', err);
      }
    }
  }, [user, setUser]);

  const updateStreak = useCallback(async () => {
    if (!user) return;

    const newStreak = user.streak + 1;
    setUser({ ...user, streak: newStreak });

    if (newStreak % 7 === 0) {
      // Weekly streak bonus
      await addXp(100, 'Bônus de 7 dias de streak!');
      await addCoins(50, 'Bônus semanal de streak');
    }

    // Update in Supabase if configured
    if (isSupabaseConfigured && user.id) {
      try {
        await supabase.rpc('update_streak', { user_id: user.id } as any);
      } catch (err) {
        console.error('Error updating streak in database:', err);
      }
    }
  }, [user, setUser, addXp, addCoins]);

  const completeMission = useCallback(async (missionId: string) => {
    const mission = mockMissions.find(m => m.id === missionId);
    if (!mission) return;

    await addXp(mission.xpReward, `Missão: ${mission.title}`);
    await addCoins(mission.coinReward);

    addNotification({
      id: Date.now().toString(),
      title: 'Missão Completa! ✅',
      message: `Você completou: ${mission.title}`,
      type: 'achievement',
      read: false,
      timestamp: new Date().toISOString(),
      icon: mission.icon,
    });
  }, [addXp, addCoins, addNotification]);

  const unlockAchievement = useCallback(async (achievementId: string) => {
    const achievement = mockAchievements.find(a => a.id === achievementId);
    if (!achievement) return;

    await addXp(achievement.xpReward, `Conquista: ${achievement.title}`);
    await addCoins(achievement.coinReward);

    addNotification({
      id: Date.now().toString(),
      title: 'Conquista Desbloqueada! 🏆',
      message: `${achievement.title} - ${achievement.description}`,
      type: 'achievement',
      read: false,
      timestamp: new Date().toISOString(),
      icon: achievement.icon,
    });

    toast.success(`🏆 Conquista: ${achievement.title}!`, {
      duration: 4000,
    });
  }, [addXp, addCoins, addNotification]);

  return {
    loading,
    currentLevel: getCurrentLevel(),
    nextLevel: getNextLevel(),
    xpProgress: getXpProgress(),
    achievements: mockAchievements,
    missions: mockMissions,
    levels: LEVELS,
    addXp,
    addCoins,
    updateStreak,
    completeMission,
    unlockAchievement,
  };
}
