import { useState, useEffect, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { mockCustomers } from '../data/mockData';
import type { Customer } from '../types/database';

export function useCustomers(tenantId?: string) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCustomers = useCallback(async () => {
    if (!isSupabaseConfigured || !tenantId) {
      // Use mock data in demo mode
      setCustomers(mockCustomers as unknown as Customer[]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .eq('tenant_id', tenantId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCustomers(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao carregar clientes');
      // Fallback to mock data
      setCustomers(mockCustomers as unknown as Customer[]);
    } finally {
      setLoading(false);
    }
  }, [tenantId]);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  const stats = {
    total: customers.length,
    highEngagement: customers.filter(c => c.engagement_level === 'high' || (c as any).engagement === 'alta').length,
    mediumEngagement: customers.filter(c => c.engagement_level === 'medium' || (c as any).engagement === 'media').length,
    lowEngagement: customers.filter(c => c.engagement_level === 'low' || (c as any).engagement === 'baixa').length,
    totalSpent: customers.reduce((sum, c) => sum + (c.total_spent || (c as any).totalSpent || 0), 0),
  };

  const addCustomer = async (customer: Omit<Customer, 'id' | 'created_at' | 'updated_at'>) => {
    if (!isSupabaseConfigured) {
      const newCustomer = { ...customer, id: Date.now().toString(), created_at: new Date().toISOString(), updated_at: new Date().toISOString() } as Customer;
      setCustomers(prev => [newCustomer, ...prev]);
      return { success: true, data: newCustomer };
    }

    try {
      const { data, error } = await supabase
        .from('customers')
        .insert(customer as never)
        .select()
        .single();

      if (error) throw error;
      setCustomers(prev => [data as Customer, ...prev]);
      return { success: true, data };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Erro ao adicionar cliente' };
    }
  };

  const updateCustomer = async (id: string, updates: Partial<Customer>) => {
    if (!isSupabaseConfigured) {
      setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
      return { success: true };
    }

    try {
      const { error } = await supabase
        .from('customers')
        .update(updates as never)
        .eq('id', id);

      if (error) throw error;
      setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
      return { success: true };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Erro ao atualizar cliente' };
    }
  };

  return {
    customers,
    loading,
    error,
    stats,
    refetch: fetchCustomers,
    addCustomer,
    updateCustomer,
  };
}
