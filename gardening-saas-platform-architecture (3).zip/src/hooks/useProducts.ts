import { useState, useEffect, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { mockProducts } from '../data/mockData';
import type { Product } from '../types/database';

export function useProducts(tenantId?: string) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = useCallback(async () => {
    if (!isSupabaseConfigured || !tenantId) {
      // Use mock data in demo mode
      setProducts(mockProducts as unknown as Product[]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('tenant_id', tenantId)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao carregar produtos');
      // Fallback to mock data
      setProducts(mockProducts as unknown as Product[]);
    } finally {
      setLoading(false);
    }
  }, [tenantId]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const addProduct = async (product: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => {
    if (!isSupabaseConfigured) {
      // Mock add
      const newProduct = { ...product, id: Date.now().toString(), created_at: new Date().toISOString(), updated_at: new Date().toISOString() } as Product;
      setProducts(prev => [newProduct, ...prev]);
      return { success: true, data: newProduct };
    }

    try {
      const { data, error } = await supabase
        .from('products')
        .insert(product as never)
        .select()
        .single();

      if (error) throw error;
      setProducts(prev => [data as Product, ...prev]);
      return { success: true, data };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Erro ao adicionar produto' };
    }
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    if (!isSupabaseConfigured) {
      setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
      return { success: true };
    }

    try {
      const { error } = await supabase
        .from('products')
        .update(updates as never)
        .eq('id', id);

      if (error) throw error;
      setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
      return { success: true };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Erro ao atualizar produto' };
    }
  };

  const deleteProduct = async (id: string) => {
    if (!isSupabaseConfigured) {
      setProducts(prev => prev.filter(p => p.id !== id));
      return { success: true };
    }

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setProducts(prev => prev.filter(p => p.id !== id));
      return { success: true };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Erro ao excluir produto' };
    }
  };

  return {
    products,
    loading,
    error,
    refetch: fetchProducts,
    addProduct,
    updateProduct,
    deleteProduct,
  };
}
