import { useStore } from '../../store/useStore';
import { LEVELS } from '../../data/mockData';
import { Trophy, Lock, Flame, Target } from 'lucide-react';

const achievements = [
  { id: '1', title: 'Primeiro Broto', desc: 'Adicione sua primeira planta', icon: '🌱', xp: 50 },
  { id: '2', title: 'Jardineiro Dedicado', desc: 'Faça login 7 dias seguidos', icon: '🔥', xp: 150 },
  { id: '3', title: 'Mão Verde', desc: 'Mantenha 5 plantas saudáveis', icon: '🖐️', xp: 200 },
  { id: '4', title: 'Fotógrafo Botânico', desc: 'Registre 10 fotos no diário', icon: '📸', xp: 250 },
  { id: '5', title: 'Mestre da Irrigação', desc: 'Regue suas plantas 30 vezes', icon: '💧', xp: 300 },
  { id: '6', title: 'Colecionador', desc: 'Tenha 10 espécies diferentes', icon: '🏆', xp: 500 },
  { id: '7', title: 'Guru das Plantas', desc: 'Alcance nível 10', icon: '🧙', xp: 1000 },
  { id: '8', title: 'Comprador VIP', desc: 'Faça 10 compras na loja', icon: '🛒', xp: 400 },
];

export default function ClienteGamificacao() {
  const { user } = useStore();
  if (!user) return null;

  const currentLevel = LEVELS.find(l => l.level === user.level) || LEVELS[0];

  return (
    <div className="space-y-6 pb-24">
      {/* Level Progress */}
      <div className="bg-gradient-to-br from-purple-600 via-indigo-700 to-blue-800 rounded-2xl p-6 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 text-8xl opacity-10">🏆</div>
        <div className="relative">
          <h2 className="text-lg font-bold mb-4">Progressão de Nível</h2>
          <div className="flex items-center gap-3 overflow-x-auto pb-2">
            {LEVELS.slice(0, 7).map((level) => (
              <div key={level.level} className="flex flex-col items-center flex-shrink-0">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg ${level.level <= user.level ? 'bg-white/20' : 'bg-white/5'}`}>
                  {level.level <= user.level ? level.icon : <Lock className="w-4 h-4 text-white/30" />}
                </div>
                <span className={`text-xs mt-1 ${level.level <= user.level ? 'text-white' : 'text-white/30'}`}>
                  Nv.{level.level}
                </span>
              </div>
            ))}
          </div>
          <div className="bg-white/10 rounded-xl p-4 mt-4">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{currentLevel.icon}</span>
              <div>
                <div className="font-bold">Nível {user.level} — {currentLevel.title}</div>
                <div className="text-sm text-purple-200">{user.xp} XP total</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white rounded-xl p-4 border border-gray-100 text-center">
          <Flame className="w-6 h-6 mx-auto mb-1 text-orange-500" />
          <div className="text-xl font-bold text-gray-900">{user.streak}</div>
          <div className="text-xs text-gray-500">Dias Seguidos</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-100 text-center">
          <Trophy className="w-6 h-6 mx-auto mb-1 text-amber-500" />
          <div className="text-xl font-bold text-gray-900">0</div>
          <div className="text-xs text-gray-500">Conquistas</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-100 text-center">
          <Target className="w-6 h-6 mx-auto mb-1 text-blue-500" />
          <div className="text-xl font-bold text-gray-900">0</div>
          <div className="text-xs text-gray-500">Missões</div>
        </div>
      </div>

      {/* Achievements */}
      <div>
        <h3 className="font-bold text-gray-900 mb-4">🏆 Conquistas para Desbloquear</h3>
        <div className="grid grid-cols-2 gap-3">
          {achievements.map(a => (
            <div key={a.id} className="bg-white rounded-xl p-4 border border-gray-100 opacity-70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">{a.icon}</span>
                <Lock className="w-3.5 h-3.5 text-gray-300" />
              </div>
              <h4 className="text-sm font-semibold text-gray-900">{a.title}</h4>
              <p className="text-xs text-gray-500 mb-2">{a.desc}</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-gray-200 rounded-full" style={{ width: '0%' }} />
                </div>
                <span className="text-xs text-gray-400">0%</span>
              </div>
              <div className="mt-2 text-xs text-amber-600">+{a.xp} XP</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
