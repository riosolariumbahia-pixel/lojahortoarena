import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { LEVELS } from '../../data/mockData';
import { Droplets, TrendingUp, Flame, Coins, Plus, X, Leaf } from 'lucide-react';
import toast from 'react-hot-toast';

interface MyPlant {
  id: string;
  name: string;
  species: string;
  health: number;
  waterDays: number;
  growth: number;
  addedAt: string;
}

interface MyMission {
  id: string;
  title: string;
  icon: string;
  progress: number;
  max: number;
  xp: number;
  done: boolean;
}

export default function ClienteHome() {
  const { user, setUser } = useStore();
  const [plants, setPlants] = useState<MyPlant[]>([]);
  const [showAddPlant, setShowAddPlant] = useState(false);
  const [plantForm, setPlantForm] = useState({ name: '', species: '', waterDays: '3' });

  const [missions] = useState<MyMission[]>([
    { id: '1', title: 'Adicione sua primeira planta', icon: '🌱', progress: 0, max: 1, xp: 50, done: false },
    { id: '2', title: 'Consulte a IA Jardineiro', icon: '🤖', progress: 0, max: 1, xp: 30, done: false },
    { id: '3', title: 'Explore o Scanner IA', icon: '📸', progress: 0, max: 1, xp: 20, done: false },
  ]);

  if (!user) return null;

  const currentLevel = LEVELS.find(l => l.level === user.level) || LEVELS[0];
  const nextLevel = LEVELS.find(l => l.level === user.level + 1);
  const xpProgress = nextLevel ? Math.max(0, ((user.xp - currentLevel.xpRequired) / (nextLevel.xpRequired - currentLevel.xpRequired)) * 100) : 100;

  const addPlant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!plantForm.name.trim()) return;
    const newPlant: MyPlant = {
      id: Date.now().toString(),
      name: plantForm.name,
      species: plantForm.species || 'Não identificada',
      health: 100,
      waterDays: parseInt(plantForm.waterDays) || 3,
      growth: 0,
      addedAt: new Date().toISOString(),
    };
    setPlants(prev => [...prev, newPlant]);

    // Ganhar XP
    const newXp = user.xp + 50;
    let newLevel = user.level;
    for (let i = LEVELS.length - 1; i >= 0; i--) {
      if (newXp >= LEVELS[i].xpRequired) { newLevel = LEVELS[i].level; break; }
    }
    setUser({ ...user, xp: newXp, level: newLevel, coins: user.coins + 20 });
    toast.success(`+50 XP! Planta "${plantForm.name}" adicionada 🌱`);
    setPlantForm({ name: '', species: '', waterDays: '3' });
    setShowAddPlant(false);
  };

  const waterPlant = (id: string) => {
    setPlants(prev => prev.map(p => p.id === id ? { ...p, health: Math.min(100, p.health + 5), growth: Math.min(100, p.growth + 2) } : p));
    const newXp = user.xp + 10;
    let newLevel = user.level;
    for (let i = LEVELS.length - 1; i >= 0; i--) {
      if (newXp >= LEVELS[i].xpRequired) { newLevel = LEVELS[i].level; break; }
    }
    setUser({ ...user, xp: newXp, level: newLevel, coins: user.coins + 5 });
    toast.success('+10 XP! Planta regada 💧');
  };

  return (
    <div className="space-y-6 pb-24">
      {/* User Header */}
      <div className="bg-gradient-to-br from-garden-600 via-garden-700 to-emerald-800 rounded-2xl p-6 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 text-8xl opacity-10">🌿</div>
        <div className="relative">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-2xl">
              {currentLevel.icon}
            </div>
            <div>
              <h2 className="text-xl font-bold">Olá, {user.name.split(' ')[0]}! 👋</h2>
              <p className="text-garden-200 text-sm">Nível {user.level} — {currentLevel.title}</p>
            </div>
          </div>

          {/* XP Bar */}
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs text-garden-200 mb-1">
              <span>{user.xp} XP</span>
              <span>{nextLevel ? `${nextLevel.xpRequired} XP` : 'MAX'}</span>
            </div>
            <div className="h-3 bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-yellow-400 to-amber-500 rounded-full transition-all duration-500" style={{ width: `${xpProgress}%` }} />
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
              <Flame className="w-5 h-5 mx-auto mb-1 text-orange-400" />
              <div className="text-lg font-bold">{user.streak}</div>
              <div className="text-xs text-garden-200">Streak</div>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
              <Coins className="w-5 h-5 mx-auto mb-1 text-yellow-400" />
              <div className="text-lg font-bold">{user.coins}</div>
              <div className="text-xs text-garden-200">Moedas</div>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-xl p-3 text-center">
              <Leaf className="w-5 h-5 mx-auto mb-1 text-green-400" />
              <div className="text-lg font-bold">{plants.length}</div>
              <div className="text-xs text-garden-200">Plantas</div>
            </div>
          </div>
        </div>
      </div>

      {/* Missions */}
      <div>
        <h3 className="font-bold text-gray-900 mb-3">Missões Iniciais 🎯</h3>
        <div className="space-y-2">
          {missions.map(m => {
            const done = (m.id === '1' && plants.length > 0);
            return (
              <div key={m.id} className={`bg-white rounded-xl p-4 border flex items-center gap-3 ${done ? 'border-green-200 bg-green-50/50' : 'border-gray-100'}`}>
                <span className="text-2xl">{m.icon}</span>
                <div className="flex-1">
                  <span className={`text-sm font-medium ${done ? 'text-green-700 line-through' : 'text-gray-900'}`}>{m.title}</span>
                  {done && <span className="ml-2 text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">✓</span>}
                </div>
                <div className="text-right">
                  <div className="text-xs text-amber-600 font-medium">+{m.xp} XP</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* My Plants */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-gray-900">Minhas Plantas 🌿</h3>
          <button onClick={() => setShowAddPlant(true)} className="px-3 py-1.5 bg-garden-600 text-white rounded-lg text-xs font-medium flex items-center gap-1 hover:bg-garden-700">
            <Plus className="w-3.5 h-3.5" /> Adicionar
          </button>
        </div>

        {plants.length === 0 ? (
          <div className="bg-white rounded-2xl border-2 border-dashed border-gray-200 p-8 text-center">
            <div className="text-5xl mb-3">🌱</div>
            <h4 className="font-semibold text-gray-900 mb-1">Nenhuma planta ainda</h4>
            <p className="text-sm text-gray-500 mb-4">Adicione sua primeira planta para começar a ganhar XP!</p>
            <button onClick={() => setShowAddPlant(true)} className="px-5 py-2.5 bg-garden-600 text-white rounded-xl text-sm font-medium hover:bg-garden-700 inline-flex items-center gap-2">
              <Plus className="w-4 h-4" /> Adicionar Primeira Planta
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {plants.map(plant => (
              <div key={plant.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                <div className="aspect-square bg-gradient-to-br from-garden-50 to-emerald-50 flex items-center justify-center">
                  <span className="text-5xl">{plant.species.toLowerCase().includes('rosa') ? '🌹' : plant.species.toLowerCase().includes('tomate') ? '🍅' : plant.species.toLowerCase().includes('suculenta') ? '🪴' : plant.species.toLowerCase().includes('orquid') ? '🌸' : '🌿'}</span>
                </div>
                <div className="p-3">
                  <h4 className="font-semibold text-sm text-gray-900">{plant.name}</h4>
                  <p className="text-xs text-gray-500 mb-2">{plant.species}</p>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1 text-xs text-sky-600">
                      <Droplets className="w-3 h-3" /> A cada {plant.waterDays}d
                    </div>
                    <div className="flex items-center gap-1 text-xs text-garden-600">
                      <TrendingUp className="w-3 h-3" /> {plant.growth}%
                    </div>
                  </div>
                  <button onClick={() => waterPlant(plant.id)}
                    className="w-full py-2 bg-sky-50 text-sky-700 rounded-lg text-xs font-medium hover:bg-sky-100 flex items-center justify-center gap-1">
                    <Droplets className="w-3 h-3" /> Regar +10 XP
                  </button>
                </div>
              </div>
            ))}
            {/* Add button card */}
            <button onClick={() => setShowAddPlant(true)} className="bg-white rounded-2xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center min-h-[200px] hover:border-garden-400 hover:bg-garden-50/50 transition-all">
              <Plus className="w-8 h-8 text-gray-300 mb-2" />
              <span className="text-sm text-gray-400">Adicionar</span>
            </button>
          </div>
        )}
      </div>

      {/* Add Plant Modal */}
      {showAddPlant && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setShowAddPlant(false)}>
          <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">🌱 Nova Planta</h3>
              <button onClick={() => setShowAddPlant(false)} className="p-1 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5 text-gray-400" /></button>
            </div>
            <form onSubmit={addPlant} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Nome da planta *</label>
                <input type="text" value={plantForm.name} onChange={e => setPlantForm({ ...plantForm, name: e.target.value })}
                  placeholder="Ex: Minha Rosa, Tomateiro, etc." required autoFocus
                  className="w-full mt-1 px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-garden-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Espécie</label>
                <input type="text" value={plantForm.species} onChange={e => setPlantForm({ ...plantForm, species: e.target.value })}
                  placeholder="Ex: Rosa, Tomate cereja, Suculenta..."
                  className="w-full mt-1 px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-garden-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Regar a cada (dias)</label>
                <select value={plantForm.waterDays} onChange={e => setPlantForm({ ...plantForm, waterDays: e.target.value })}
                  className="w-full mt-1 px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-garden-500">
                  <option value="1">Todo dia</option>
                  <option value="2">A cada 2 dias</option>
                  <option value="3">A cada 3 dias</option>
                  <option value="5">A cada 5 dias</option>
                  <option value="7">Semanalmente</option>
                  <option value="14">Quinzenalmente</option>
                </select>
              </div>
              <button type="submit" className="w-full py-3.5 bg-garden-600 text-white rounded-xl font-semibold hover:bg-garden-700">
                Adicionar Planta +50 XP 🌿
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
